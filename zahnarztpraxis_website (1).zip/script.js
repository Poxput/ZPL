function toggleNav() {
  const nav = document.getElementById("nav");
  nav.classList.toggle("show");
}
